import pandas as pd
import numpy as np
import nltk
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn.svm import LinearSVC
# Add any other models plan to use
# Load the dataset
df_bin = pd.read_excel("content/final_trainset.xlsx")
# Convert abstracts to lowercase to normalize the text
df_bin['ABSTRACT'] = df_bin['ABSTRACT'].apply(str.lower)
# Choose the type of vectorizer
vectortype = 'tfidf'  # Or 'countvec' for CountVectorizer

# Initialize the vectorizer
vectorizer = TfidfVectorizer() if vectortype == "tfidf" else CountVectorizer()

# Apply the vectorizer to the ABSTRACT column
X_train = vectorizer.fit_transform(df_bin['ABSTRACT'])
# Choose the model type
model_type = 'svm'  # replace this with 'nb', 'lr', etc.

# Map the model_type to the actual classifier and train it
if model_type == 'svm':
    model = LinearSVC().fit(X_train, df_bin['binary2_label'])
# Add elif blocks for other model types if necessary
# Save the vectorizer
with open('vectorizer.pkl', 'wb') as file:
    pickle.dump(vectorizer, file)

# Save the model
model_filename = f'model_{model_type}.pkl'
with open(model_filename, 'wb') as file:
    pickle.dump(model, file)
# Load the saved vectorizer
with open('vectorizer.pkl', 'rb') as file:
    loaded_vectorizer = pickle.load(file)

# Load the saved model
with open('model_svm.pkl', 'rb') as file:  # Use the correct filename
    loaded_model = pickle.load(file)

# Example of transforming and predicting new data
# replace 'new_abstracts' with actual data
new_abstracts = ["""Historically, surgical correction has been the treatment of choice for benign biliary strictures (BBS). Self-expandable metallic stents (MSs) have been useful for inoperable malignant biliary strictures; however, their use for BBS is controversial and their natural history unknown. To test our hypothesis that MSs provide only short-term benefit, we examined the long-term outcome of MSs for the treatment of BBS. Our goal was to develop a rational approach for treating BBS. Between July 1990 and December 1995, 15 patients had MSs placed for BBS and have been followed up for a mean of 86.3 months (range, 55-120 months). The mean age of the patients was 66.6 years and 12 were women. Stents were placed for surgical injury in 5 patients and underlying disease in 10 patients (lithiasis, 7; pancreatitis, 2; and primary sclerosing cholangitis, 1). One or more MSs (Gianturco-Rosch "Z" for 4 patients and Wallstents for 11 patients) were placed by percutaneous, endoscopic, or combined approaches. We considered patients to have a good clinical outcome if the stent remained patent, they required 2 or fewer invasive interventions, and they had no biliary dilation on subsequent imaging. Metallic stents were successfully placed in all 15 patients, and the mean patency rate was 30.6 months (range, 7-120 months). Five patients (33%) had a good clinical result with stent patency from 55 to 120 months. Ten patients (67%) required more than 2 radiologic and/or endoscopic procedures for recurrent cholangitis and/or obstruction (range, 7-120 months). Five of the 10 patients developed complete stent obstruction at 8, 9, 10, 15, and 120 months and underwent surgical removal of the stent and bilioenteric anastomosis. Four of these 5 patients had strictures from surgical injuries. The patient who had surgical removal 10 years after MS placement developed cholangiocarcinoma. Surgical repair remains the treatment of choice for BBS. Metallic stents should only be considered for poor surgical candidates, intrahepatic biliary strictures, or failed attempts at surgical repair. Most patients with MSs will develop recurrent cholangitis or stent obstruction and require intervention. Chronic inflammation and obstruction may predispose the patient to cholangiocarcinoma.
""",
                 """This study intends to provide new insights into the incidence and care of mucositis by the epidemiological characterization of patients with hematological malignancy treated at our institution. It also aims to understand the effectiveness of several treatments used. This is a longitudinal observational single-center study-convenience sample-which includes malignant hematologic inpatients submitted to high-dose CT from February to August 2012. We registered epidemiological data, diagnosis, oral mucositis daily questionnaire (OMDQ), World Health Organization (WHO) oral toxicity scale, and supportive medications used for mucositis. We evaluated 30 patients who had 73 episodes of hospitalization, having recorded the development of mucositis in 21.9Â % (nâ€‰=â€‰16) episodes (22 patients with acute leukemia (AL) and 8 patients with non-Hodgkin lymphoma (NHL)). Grades 3-4 mucositis was reported in 4.1Â % of the total episodes. The results of OMDQ showed some limitations in the quality of life, of patients with mucositis, related with the ability to eat and drink due to mouth pain (pâ€‰<â€‰0.001). In patients with NHL and AL, neutropenia entails an increased risk of mucositis (pâ€‰<â€‰0.001). Patients who did not initiate early prophylaxis with conservative measures developed mucositis earlier (pâ€‰<â€‰0.05). The incidence of mucositis is high, being reported mainly in AL patients, with limitations in quality of life. Grade 4 neutropenia increases mucositis risk. Early prophylaxis with basic oral care may delay mucositis. Further studies are crucial to characterize mucositis epidemiology, physiopathology, and its management.
"""]
X_new = loaded_vectorizer.transform(new_abstracts)
predictions = loaded_model.predict(X_new)

# Output the predictions
print(predictions)
