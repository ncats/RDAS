import requests

# The URL of your Flask API
url = 'http://127.0.0.1:5000/train'

# Sending a POST request to train the model
response = requests.post(url)

# Checking the response from the server
if response.status_code == 200:
    print("Model trained successfully!")
else:
    print("Error training model:", response.status_code, response.text)
