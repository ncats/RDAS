from flask import Flask, request, jsonify
import pickle

app = Flask(__name__)

# Load the trained vectorizer and model from the .pkl files
with open('vectorizer.pkl', 'rb') as file:
    vectorizer = pickle.load(file)

with open('model_svm.pkl', 'rb') as file:  # Make sure to use the correct filename
    model = pickle.load(file)

@app.route('/predict', methods=['POST',"GET"])
def predict():
    # Get the request data in JSON format
    data = request.get_json(force=True)

    # Validate the JSON payload
    if 'abstracts' not in data or not isinstance(data['abstracts'], list):
        return jsonify({"error": "Missing or invalid 'abstracts' field in request payload."}), 400

    # Preprocess and predict each abstract in the list
    results = []
    for abstract in data['abstracts']:
        abstract = abstract.lower()  # Preprocess
        abstract_vectorized = vectorizer.transform([abstract])  # Vectorize
        prediction = model.predict(abstract_vectorized)  # Predict
        results.append(prediction.tolist())

    # Return all predictions as JSON
    return jsonify({"predictions": results})


# Run the Flask app
if __name__ == '__main__':
    app.run(debug=True)
