from flask import Flask, request, jsonify
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
import joblib
import os

app = Flask(__name__)

# Path to save or load the model and vectorizer
MODEL_PATH = 'model.joblib'
VECTORIZER_PATH = 'vectorizer.joblib'

# Initialize the model and vectorizer globally (only if they are already trained and saved)
if os.path.exists(MODEL_PATH) and os.path.exists(VECTORIZER_PATH):
    vectorizer = joblib.load(VECTORIZER_PATH)
    model = joblib.load(MODEL_PATH)
else:
    vectorizer = TfidfVectorizer()
    model = LinearSVC()



@app.route('/train', methods=['GET', 'POST'])
def train_model():
    # Load dataset
    df_bin = pd.ExcelFile("content/final_trainset.xlsx").parse("Sheet1")
    # Make sure to apply lower() on the actual string data in the 'ABSTRACT' column
    df_bin['ABSTRACT'] =[i.lower() for i in  df_bin['ABSTRACT']]  # Use str.lower() on the pandas series directly

    # Train the vectorizer and model
    X_train = vectorizer.fit_transform(df_bin['ABSTRACT'])
    y_train = df_bin['binary2_label']
    print(X_train.head())
    print(y_train.head())
    # model.fit(X_train, y_train)
    #
    # # Save the fitted vectorizer and model to disk
    # joblib.dump(vectorizer, 'vectorizer.joblib')
    # joblib.dump(model, 'model.joblib')

    return jsonify({'message': 'Model and vectorizer trained and saved successfully!'})

@app.route('/predict', methods=['POST'])
def predict():
    # Ensure the model and vectorizer have been trained and loaded
    if 'vectorizer' not in globals() or 'model' not in globals():
        return jsonify({'error': 'Model and vectorizer must be trained first.'}), 500

    # Get data from request
    data = request.get_json(force=True)
    abstracts = data['abstracts']  # Expecting a list of abstracts

    # Transform abstracts to BOW
    bow_abstracts = vectorizer.transform(abstracts)

    # Make predictions
    predictions = model.predict(bow_abstracts)

    return jsonify({'predictions': predictions.tolist()})


if __name__ == '__main__':
    app.run(debug=True,port=5000)
